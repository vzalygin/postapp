rootProject.name = "postapp"
